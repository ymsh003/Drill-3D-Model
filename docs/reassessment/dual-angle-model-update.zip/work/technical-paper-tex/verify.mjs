import fs from 'node:fs';
import crypto from 'node:crypto';
import {context as c,evaluate,setValue} from '../Drill-3D-Model/tools/run_zero_axis_experiment.mjs';
import {functionalAnova} from '../Drill-3D-Model/tools/experiment_statistics.mjs';
const saved=JSON.parse(fs.readFileSync(new URL('../Drill-3D-Model/outputs/layout-interaction-experiment-data.json',import.meta.url)));
const rows=saved.rows.map(r=>evaluate(r.drill_angle_deg,r.pin_pap_in,r.val_angle_deg));
const metrics=['pap_rg_in','total_diff_in','int_diff_in','normalized_axis_misalignment','torque_free_axis_rate_per_spin'];
const errors=Object.fromEntries(metrics.map(k=>[k,Math.max(...rows.map((r,i)=>Math.abs(r[k]-saved.rows[i][k])))]));
if(Object.values(errors).some(v=>v>1e-12))throw Error('Reproduction mismatch');
const ranges={full:rows,restricted:rows.filter(r=>r.drill_angle_deg>=30&&r.drill_angle_deg<=70&&r.pin_pap_in>=3&&r.pin_pap_in<=5&&r.val_angle_deg>=30&&r.val_angle_deg<=60)};
const analysis=Object.fromEntries(Object.entries(ranges).map(([name,rs])=>[name,{n:rs.length,metrics:Object.fromEntries(metrics.map(k=>[k,functionalAnova(rs,k)]))}]));
const examples=[[45,4.5,30],[45,4.5,45],[45,4.5,60],[30,4.5,45],[70,4.5,45]].map(x=>evaluate(...x));
evaluate(45,4.5,45);const data=c.layout();
const geometry=[];
for(const p of [2,3.375,4.5,5.5])for(const v of [20,30,45,60,70]){evaluate(45,p,v);const d=c.layout(),a=c.normalize(d.dualLayout.pap),t=c.normalize(d.dualLayout.valDownTangent),normal=c.normalize(c.cross(a,t)),pin=c.normalize(d.dualLayout.pin);const measured=d.ballRadius*Math.asin(Math.abs(c.dot(pin,normal)));const formula=d.ballRadius*Math.asin(Math.sin(p/d.ballRadius)*Math.sin(v*Math.PI/180));if(Math.abs(measured-formula)>1e-10)throw Error('Geometry mismatch');geometry.push({pin_pap_in:p,val_angle_deg:v,pin_buffer_in:formula});}
const file=new URL('../Drill-3D-Model/outputs/bowling-drill-3d-prototype.html',import.meta.url);
const out={model_revision:'mass-moments-2026-09-25',date:'2026-09-25',source_sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),radius_in:data.ballRadius,fixed_inputs:saved.fixed_inputs,holes:data.holes.map(h=>({name:h.name,...c.drillSegment(h,data,c.drilledOpeningRadius(h))})),rows,analysis,errors,examples,geometry};
fs.writeFileSync(new URL('results.json',import.meta.url),JSON.stringify(out,null,2));
console.log(JSON.stringify({radius:out.radius_in,errors,examples,analysis},null,2));

