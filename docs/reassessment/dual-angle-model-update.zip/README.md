# モデル改修・再現用パッケージ

版: mass-moments-2026-09-25
対象取得コミット: 215b1f2f2b3cdecb89b8acbbf1e5d2e6c66cd128
GitHubへのpushはしていません。

## 実行

このREADMEがあるフォルダーで、Node.jsにより次を実行します。外部パッケージとネットワーク接続は不要です。

```sh
node work/Drill-3D-Model/tools/test_model_physics.mjs
node work/Drill-3D-Model/tools/test_mass_extensions.mjs
node work/Drill-3D-Model/tools/test_grip_geometry.mjs
node work/Drill-3D-Model/tools/test_experiment_reproducibility.mjs
node work/Drill-3D-Model/tools/test_layout_interaction_experiment.mjs
node work/Drill-3D-Model/tools/test_zero_axis_experiment.mjs
node work/technical-paper-tex/verify.mjs
node work/Drill-3D-Model/tools/run_mass_model.mjs work/Drill-3D-Model/tools/mass-model-example.json example-result.json
```

入力例は仮定値です。実測の初期重心・加工済み部材質量に置き換えてください。
MODEL_MASS_EXTENSION.mdに入力の単位・座標・制限・一次資料を記載しています。

## ソースへの反映

model-source.patch は上記取得コミットに対するソース用の累積差分です。
前回の理論監査の修正も含みます。更新済みのJSON/CSVは同梱ファイルを参照してください。
すでに改修済みのチェックアウトへ重ねて適用するパッチではありません。
指定コミットのソースへ `git apply --check model-source.patch` と `git apply model-source.patch` を確認済みです。
元リポジトリ全体・Git履歴の複製ではありません。

## 解釈

静的質量特性の拡張であり、実フレアやレーン反応の実測検証は未実施です。
材料別密度場と摩擦は未対応。旧互換指標D・D×Uはメーカー公式式として扱わないでください。
全リポジトリテスト成功は主張しません。旧UIを要求するtest_static_experiment.mjsの問題は未解消です。
