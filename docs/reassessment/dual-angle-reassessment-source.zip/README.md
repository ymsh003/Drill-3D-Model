# 再考察版

## TeX原稿
dual-angle-reassessed.tex、buffer.pdf、u.pdf、shares.pdfを同じフォルダーへ置きます。
WindowsのC:/Windows/FontsからBIZ-UDMinchoM.ttc、BIZ-UDGothicR.ttc、BIZ-UDGothicB.ttcを同じフォルダーへコピーします。フォント本体は同梱していません。
`tectonic dual-angle-reassessed.tex` で組版します。日本語環境を備えたXeLaTeXでも組版できます。
他のOSではsetjamainfont/setjasansfontを利用可能な日本語フォントに変更してください。

## 追加の計算検証
前回提供したdual-angle-model-update.zipを展開したルートのwork/reassessmentへverify.mjsを置きます。
`node work/reassessment/verify.mjs` でverification.jsonを再生成します。
25条件の解析微分と中心差分の比較、６候補の幾何・モデル値、仮定入力誤差の四隅を検査します。
本体の物理モデルはmass-moments-2026-09-25版を変更していません。

## プレゼン資料
黒基調16:9、23枚。1～20枚は接客本編、21～22枚は説明補足、23枚は参考資料です。
PowerPointの本文・表・棒グラフは編集できます。図版は説明用イメージです。
speaker-notes.jsonに説明上の補足と出典を収録しています。
PDFは表示確認済みのスライド画像に検索用日本語テキストを重ねています。編集にはPPTXを使ってください。
