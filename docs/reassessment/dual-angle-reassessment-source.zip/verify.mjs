import fs from 'node:fs';
import {evaluate} from '../Drill-3D-Model/tools/run_zero_axis_experiment.mjs';
const R=4.2975, rad=x=>x*Math.PI/180;
const b=(p,v)=>R*Math.asin(Math.sin(p/R)*Math.sin(v));
const deriv=(p,v)=>{const d=Math.sqrt(1-(Math.sin(p/R)*Math.sin(v))**2);return [Math.cos(p/R)*Math.sin(v)/d,R*Math.sin(p/R)*Math.cos(v)/d];};
let error=0;
for(const p of [2,3.375,4,4.5,5.5])for(const deg of [20,30,45,60,70]){
 const v=rad(deg),h=1e-5,a=deriv(p,v),n=[(b(p+h,v)-b(p-h,v))/(2*h),(b(p,v+h)-b(p,v-h))/(2*h)];
 error=Math.max(error,...a.map((x,i)=>Math.abs(x-n[i])));
}
if(error>1e-7)throw Error('Derivative check failed');
const d=deriv(4.5,rad(45)),exact=[];
for(const dp of [-1/16,1/16])for(const dv of [-2,2])exact.push(b(4.5+dp,rad(45+dv)));
const rows=[[30,4,60],[60,4,30],[45,4.5,30],[45,4.5,45],[45,4.5,60],[70,4.5,45]].map(x=>{
const r=evaluate(...x);return {angles:x,pin_buffer_in:b(x[1],rad(x[2])),psa_pap_in:R*Math.acos(Math.sin(x[1]/R)*Math.cos(rad(x[0]))),pap_rg_in:r.pap_rg_in,total_diff_in:r.total_diff_in,K:r.torque_free_axis_rate_per_spin};});
const report={R,derivative_max_abs_error:error,derivative_conditions:25,sensitivity:{p:4.5,beta_deg:45,db_dp:d[0],db_dbeta_rad:d[1],base:b(4.5,rad(45)),assumed_dp_in:1/16,assumed_dbeta_deg:2,linear_bound:Math.abs(d[0])/16+Math.abs(d[1])*rad(2),corner_min:Math.min(...exact),corner_max:Math.max(...exact)},rows};
fs.writeFileSync(new URL('verification.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
